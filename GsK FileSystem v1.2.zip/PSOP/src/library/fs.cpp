// fs.cpp: File System

#include "sfs/fs.h"

#include <algorithm>
#include <unistd.h>
#include <assert.h>
#include <stdio.h>
#include <string.h>
#include <sys/mman.h>

char*FileSystem::superBlockFS=nullptr;

void FileSystem::readSuperBlock(Disk *disk, SuperBlock &superblock)
{
    if(!disk->mounted())
    {
        printf("EROARE la montarea discului\n");
        return;
    }
    Block superblk;
    disk->read(0,superblk.Data);
    std::memcpy(&superblock,&superblk.Super,sizeof(SuperBlock));
}

void FileSystem::writeSuperBlock(Disk *disk, const SuperBlock &superblock)
{
    if(!disk->mounted())
    {
        printf("EROARE la montarea discului\n");
        return;
    }
    Block superblk;
    disk->read(0,superblk.Data);
    std::memcpy(&superblk.Super,&superblock,sizeof(SuperBlock));
    disk->write(0,superblk.Data);
}

void FileSystem::readInode(Disk *disk, uint32_t inumber, Inode &inode)
{
    if(!disk->mounted())
    {
        printf("EROARE la montarea discului\n");
        return;
    }
    uint32_t blocknum=1+inumber/INODES_PER_BLOCK;
    uint32_t offset=(inumber%INODES_PER_BLOCK)*sizeof(Inode);

    Block inodeBlock;
    disk->read(blocknum,inodeBlock.Data);
    std::memcpy(&inode,reinterpret_cast<char*>(&inodeBlock.Inodes)+offset,sizeof(Inode));
}

void FileSystem::writeInode(Disk *disk, uint32_t inumber, const Inode &inode)
{
    if(!disk->mounted())
    {
        printf("EROARE la montarea discului\n");
        return;
    }
    uint32_t blocknum = 1 + inumber / INODES_PER_BLOCK;
    uint32_t offset = (inumber % INODES_PER_BLOCK) * sizeof(Inode);

    Block inodeBlock;
    disk->read(blocknum, inodeBlock.Data);

    std::memcpy(reinterpret_cast<char*>(inodeBlock.Inodes) + offset, &inode, sizeof(Inode));

    disk->write(blocknum, inodeBlock.Data);
}

void FileSystem::readBlock(Disk *disk, uint32_t blocknum, Block &block)
{
    if(!disk->mounted())
    {
        printf("EROARE la montarea discului\n");
        return;
    }
    disk->read(blocknum,block.Data);
}

void FileSystem::writeBlock(Disk *disk, uint32_t blocknum, const Block &block)
{
    if(!disk->mounted())
    {
        printf("EROARE la montarea discului\n");
        return;
    }
    Block writableBlock = block;
    disk->write(blocknum, writableBlock.Data);
}

void FileSystem::debug(Disk* disk) {
    Block superBlock;
    // Citim superblock-ul
    disk->read(0, superBlock.Data);

    printf("SuperBlock:\n");
    printf("    %u blocks\n", superBlock.Super.Blocks);
    printf("    %u inode blocks\n", superBlock.Super.InodeBlocks);
    printf("    %u inodes\n", superBlock.Super.Inodes);

    // Afișăm informații despre inode-uri
    for (uint32_t blockNum = 1; blockNum <= superBlock.Super.InodeBlocks; ++blockNum) {
        Block inodeBlock;
        disk->read(blockNum, inodeBlock.Data);

        for (uint32_t i = 0; i < INODES_PER_BLOCK; ++i) {
            Inode& inode = inodeBlock.Inodes[i];
            if (inode.Valid) {
                printf("Inode %u:\n", (blockNum - 1) * INODES_PER_BLOCK + i);
                printf("    Size: %u bytes\n", inode.Size);
                printf("    Direct Pointers: ");
                for (uint32_t j = 0; j < POINTERS_PER_INODE; ++j) {
                    printf("%u ", inode.Direct[j]);
                }
                printf("\n");
                printf("    Indirect Pointer: %u\n", inode.Indirect);
            }
        }
    }
}



bool FileSystem::format(Disk *disk) {

    ftruncate(disk->FileDescriptor,0);

    superBlockFS=(char*)malloc(4096*sizeof(char));
    Block* superBlock=reinterpret_cast<Block*>(superBlockFS);
    superBlock->Super.MagicNumber=MAGIC_NUMBER;
    superBlock->Super.Blocks=disk->size();
    superBlock->Super.InodeBlocks=superBlock->Super.Blocks/10;
    superBlock->Super.Inodes=superBlock->Super.InodeBlocks*INODES_PER_BLOCK;

    disk->write(0,superBlockFS);

    for (uint32_t inodeBlockNum = 1; inodeBlockNum <= superBlock->Super.InodeBlocks; ++inodeBlockNum) {
        Block inodeBlock;
        // Initializare fiecare inode din blocul de inode-uri ca fiind nevalid
        for (uint32_t i = 0; i < INODES_PER_BLOCK; ++i) {
            inodeBlock.Inodes[i].Valid = 0;
        }
        // Scriere bloc de inode-uri pe disc
        disk->write(inodeBlockNum, inodeBlock.Data);
    }

    // Restul codului pentru umplerea cu date goale a blocurilor
    // Pregatim un bloc de inode-uri pentru a le adăuga înainte de blocurile goale
    Block inodeBlock;
    for (uint32_t i = 0; i < INODES_PER_BLOCK; ++i) {
        inodeBlock.Inodes[i].Valid = 0;
    }

    // Adaugam blocurile de inode-uri înainte de blocurile goale
    for (uint32_t inodeBlockNum = 1; inodeBlockNum <= superBlock->Super.InodeBlocks; ++inodeBlockNum) {
        disk->write(inodeBlockNum, inodeBlock.Data);
    }

    // Adaugam blocurile goale ramase
    for (uint32_t dataBlockNum = superBlock->Super.InodeBlocks + 1; dataBlockNum < superBlock->Super.Blocks; ++dataBlockNum) {
        Block emptyBlock;
        disk->write(dataBlockNum, emptyBlock.Data);
    }

    return true;

}


bool FileSystem::mount(Disk *disk) {
    if(disk->mounted())
    {
        printf("Disk-ul e deja montat\n");
        return false;
    }
    Block* superBlockAux=reinterpret_cast<Block*>(superBlockFS);
    if(superBlockAux->Super.MagicNumber!=MAGIC_NUMBER)
    {
        printf("EROARE\n");
        return false;
    }
    disk->mount();
    return true;
}

bool FileSystem::unmount(Disk *disk)
{
    if(disk->mounted())
    {
        disk->unmount();
    }
    return true;
} 

ssize_t FileSystem::create(Disk* disk) {
    SuperBlock superBlock;
    readSuperBlock(disk, superBlock);

    for (uint32_t blockNum = 1; blockNum <= superBlock.InodeBlocks; ++blockNum) {
        Block inodeBlock{};
        disk->read(blockNum, inodeBlock.Data);
        for (uint32_t i = 0; i < INODES_PER_BLOCK; ++i) {
            Inode& inode = inodeBlock.Inodes[i];
            if (!inode.Valid) {
                for(int i=0;i<POINTERS_PER_INODE;i++)
                {
                    inode.Direct[i]=0;
                }
                inode.Indirect=0;
                inode.Valid = 1;  
                inode.Size = 0;
                writeInode(disk, (blockNum - 1) * INODES_PER_BLOCK + i, inode);
                return (blockNum - 1) * INODES_PER_BLOCK + i;
            }
        }
    }
    printf("Nu s-au găsit inode-uri libere\n");
    return -1;
}



bool FileSystem::remove(Disk* disk, size_t inumber) {
    SuperBlock superBlock;
    readSuperBlock(disk, superBlock);

    uint32_t blockNum = 1 + inumber / INODES_PER_BLOCK;
    uint32_t offset = (inumber % INODES_PER_BLOCK) * sizeof(Inode);

    Inode inode;
    readInode(disk, inumber, inode);

    if (!inode.Valid) {
        printf("EROARE: Inode-ul nu este valid.\n");
        return false;
    }

    for (uint32_t i = 0; i < POINTERS_PER_INODE; ++i) {
        if (inode.Direct[i] != 0) {
            disk->freeBlock(inode.Direct[i]);
            inode.Direct[i] = 0;
        }
    }

    if (inode.Indirect != 0) {
        Block indirectBlock;
        disk->read(inode.Indirect, indirectBlock.Data);

        for (uint32_t i = 0; i < POINTERS_PER_BLOCK; ++i) {
            if (indirectBlock.Pointers[i] != 0) {
                disk->freeBlock(indirectBlock.Pointers[i]);
                indirectBlock.Pointers[i] = 0;
            }
        }

        disk->freeBlock(inode.Indirect);
        inode.Indirect = 0;
    }

    // Marcăm inode-ul ca nevalid și îl scriem înapoi pe disc
    inode.Valid = 0;
    writeInode(disk, inumber, inode);

    return true;
}



ssize_t FileSystem::stat(Disk* disk, size_t inumber) {
    Inode inode;
    readInode(disk, inumber, inode);

    if (!inode.Valid) {
        printf("EROARE: Inode-ul nu este valid.\n");
        return -1; 
    }

    printf("Inode %zu:\n", inumber);
    printf("    Size: %u bytes\n", inode.Size);
    printf("    Direct Pointers: ");
    for (uint32_t i = 0; i < POINTERS_PER_INODE; ++i) {
        printf("%u ", inode.Direct[i]);
    }
    printf("\n");
    printf("    Indirect Pointer: %u\n", inode.Indirect);

    return 0; 
}


ssize_t FileSystem::read(size_t inumber, char *data, size_t length, size_t offset) {
   
    return 0;
}


#include <iostream>
#include <fcntl.h>
#include <sys/mman.h>
#include <unistd.h>

ssize_t FileSystem::write(Disk* disk, size_t inumber, char *data, size_t length, size_t offset) {
    Inode inode;
    readInode(disk, inumber, inode);
    const size_t ds=4096;
    if (!inode.Valid) {
        printf("EROARE: Inode-ul nu este valid.\n");
        return -1; 
    }

    uint32_t firstBlock = offset / ds;
    uint32_t blockOffset = offset % ds;

    uint32_t requiredBlocks = (offset + length + Disk::BLOCK_SIZE - 1) / ds;

    for (uint32_t i = firstBlock; i < POINTERS_PER_INODE && i < requiredBlocks; ++i) {
        if (inode.Direct[i] == 0) {
            inode.Direct[i] = disk->allocateBlock(); 
        }

        Block dataBlock;
        disk->read(inode.Direct[i], dataBlock.Data);
        std::memcpy(dataBlock.Data + blockOffset, data, std::min(length, ds - blockOffset));
        disk->write(inode.Direct[i], dataBlock.Data);

        data += std::min(length, ds - blockOffset);
        length -= std::min(length, ds - blockOffset);
        blockOffset = 0;
    }

    if (length > 0 && inode.Indirect != 0) {
        Block indirectBlock;
        disk->read(inode.Indirect, indirectBlock.Data);

        for (uint32_t i = firstBlock - POINTERS_PER_INODE; i < POINTERS_PER_BLOCK && i < requiredBlocks; ++i) {
            if (indirectBlock.Pointers[i] == 0) {
                indirectBlock.Pointers[i] = disk->allocateBlock(); 
            }

            Block dataBlock;
            disk->read(indirectBlock.Pointers[i], dataBlock.Data);
            std::memcpy(dataBlock.Data, data, std::min(length, ds));
            disk->write(indirectBlock.Pointers[i], dataBlock.Data);

            data += std::min(length, ds);
            length -= std::min(length, ds);
        }

        disk->write(inode.Indirect, indirectBlock.Data);
    }

    if (offset + length > inode.Size) {
        inode.Size = offset + length;
        writeInode(disk, inumber, inode);
    }

    return length; 
}

