// disk.h: Disk emulator

#pragma once
#include <stdlib.h>
#include <cstring>
#include <unistd.h>
#include <cstdint>
#include <vector>
#include <cstdio>
class Disk {
private:
    int	    FileDescriptor; // File descriptor of disk image
    size_t  Blocks;	    // Number of blocks in disk image
    size_t  Reads;	    // Number of reads performed
    size_t  Writes;	    // Number of writes performed
    size_t  Mounts;	    // Number of mounts
    friend class FileSystem;
    void sanity_check(int blocknum, char *data);
    static uint32_t nextFreeBlock;
    int diskDescriptor;
    std::vector<bool> bitmap; 
public:
    const static size_t BLOCK_SIZE = 4096;
    bool lastMountUmount;
    Disk() : FileDescriptor(0), Blocks(0), Reads(0), Writes(0), Mounts(0),bitmap() {}
    
    ~Disk();

    void open(const char *path, size_t nblocks);
    uint32_t allocateBlock();
    size_t size() const { return Blocks; }
    int getDescriptor(){ printf("    %d    \n",this->diskDescriptor); return this->diskDescriptor;}

    bool mounted() const { return Mounts > 0; }

    void mount() {lastMountUmount=true; Mounts++; }

    void unmount() { lastMountUmount=false; if (Mounts > 0) Mounts--; }
    size_t getMounts(){return Mounts;}
    void read(int blocknum, char *data);
    
    void write(int blocknum, char *data);
    void freeBlock(uint32_t blocknum);
    void writeBlock(uint32_t blocknum, const char* data, size_t length, size_t offset) {
        // Verificăm că nu scriem peste limita blocului
        if (offset + length > BLOCK_SIZE) {
            printf("writeBlock: trying to write beyond block boundaries.");
        }

        // Calculăm adresa fizică unde trebuie să scriem
        off_t pos = ::lseek(FileDescriptor, blocknum * BLOCK_SIZE + offset, SEEK_SET);
        if (pos == -1) {
            printf("writeBlock: lseek failed.");
        }

        size_t bytesWritten = static_cast<size_t>(::write(FileDescriptor, data, length));
        if (bytesWritten != static_cast<size_t>(length)){
            printf("writeBlock: write failed.");
        }
    }
};