// disk.cpp: disk emulator

#include "sfs/disk.h"

#include <stdexcept>

//THIS IS THE DISK FILE WHERE I EMULATE THE DISK
//THIS FILE IS GOOD, ALL THE FUNCTIONS WORK, YOU CANNOT MODIFY FROM HERE 
#include <errno.h>
#include <fcntl.h>
#include <string.h>
#include <unistd.h>

uint32_t Disk::nextFreeBlock=1;

void Disk::open(const char *path, size_t nblocks) {
    FileDescriptor = ::open(path, O_RDWR|O_CREAT, 0600);
    if (FileDescriptor < 0) {
    	char what[BUFSIZ];
    	snprintf(what, BUFSIZ, "Unable to open %s: %s", path);
    	throw std::runtime_error(what);
    }
    this->diskDescriptor=1;
    if (ftruncate(FileDescriptor, nblocks*BLOCK_SIZE) < 0) {
    	char what[BUFSIZ];
    	snprintf(what, BUFSIZ, "Unable to open %s: %s", path, strerror(errno));
    	throw std::runtime_error(what);
    }

    Blocks = nblocks;
    Reads  = 0;
    Writes = 0;
    bitmap = std::vector<bool>(nblocks, false);
}

Disk::~Disk() {
    if (FileDescriptor > 0) {
    	printf("%lu disk block reads\n", Reads);
    	printf("%lu disk block writes\n", Writes);
    	close(FileDescriptor);
    	FileDescriptor = 0;
    }
}

void Disk::sanity_check(int blocknum, char *data) {
    char what[BUFSIZ];

    if (blocknum < 0) {
    	snprintf(what, BUFSIZ, "blocknum (%d) is negative!", blocknum);
    	throw std::invalid_argument(what);
    }

    if (blocknum >= (int)Blocks) {
    	snprintf(what, BUFSIZ, "blocknum (%d) is too big!", blocknum);
    	throw std::invalid_argument(what);
    }

    if (data == NULL) {
    	snprintf(what, BUFSIZ, "null data pointer!");
    	throw std::invalid_argument(what);
    }
}
uint32_t Disk::allocateBlock() {
     for (uint32_t i = 1; i < Blocks; i++) {
         if (!bitmap[i]) {
             bitmap[i] = true;
             return i;
         }
     }
     return 0; // Dacă toate blocurile sunt ocupate, returnăm 0
    
}

void Disk::read(int blocknum, char *data) {
    sanity_check(blocknum, data);

    if (lseek(FileDescriptor, blocknum*BLOCK_SIZE, SEEK_SET) < 0) {
    	char what[BUFSIZ];
    	snprintf(what, BUFSIZ, "Unable to lseek %d: %s", blocknum, strerror(errno));
    	throw std::runtime_error(what);
    }

    if (::read(FileDescriptor, data, BLOCK_SIZE) != BLOCK_SIZE) {
    	char what[BUFSIZ];
    	snprintf(what, BUFSIZ, "Unable to read %d: %s", blocknum, strerror(errno));
    	throw std::runtime_error(what);
    }

    Reads++;
}

void Disk::write(int blocknum, char *data) {
    sanity_check(blocknum, data);

    if (lseek(FileDescriptor, blocknum*BLOCK_SIZE, SEEK_SET) < 0) {
    	char what[BUFSIZ];
    	snprintf(what, BUFSIZ, "Unable to lseek %d: %s", blocknum, strerror(errno));
    	throw std::runtime_error(what);
    }

    if (::write(FileDescriptor, data, BLOCK_SIZE) != BLOCK_SIZE) {
    	char what[BUFSIZ];
    	snprintf(what, BUFSIZ, "Unable to write %d: %s", blocknum, strerror(errno));
    	throw std::runtime_error(what);
    }

    Writes++;
}

void Disk::freeBlock(uint32_t blocknum) {
    //sanity_check(blocknum, nullptr);

    // Marcam blocul ca fiind liber în bitmap
    bitmap[blocknum] = false;

    // Ștergem conținutul blocului din disc
    char zeroBuffer[BLOCK_SIZE] = {0};
    writeBlock(blocknum, zeroBuffer, BLOCK_SIZE, 0);
}

