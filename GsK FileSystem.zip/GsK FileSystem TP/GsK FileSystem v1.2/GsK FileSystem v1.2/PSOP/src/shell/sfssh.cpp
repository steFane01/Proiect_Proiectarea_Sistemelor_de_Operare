
#include "sfs/disk.h"
#include "sfs/fs.h"

#include <sstream>
#include <string>
#include <stdexcept>

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

//HERE IS THE MAIN FILE
//THE NEXT FUNCTIONS ARE WORKING PROPERLY: THE COPYIN AND COPYOUT DOESN'T WORK 
#define streq(a, b) (strcmp((a), (b)) == 0)


void do_debug(Disk &disk, FileSystem &fs, int args, char *arg1, char *arg2);
void do_format(Disk &disk, FileSystem &fs, int args, char *arg1, char *arg2);
void do_mount(Disk &disk, FileSystem &fs, int args, char *arg1, char *arg2);
void do_unmount(Disk &disk, FileSystem &fs, int args, char *arg1, char *arg2);
void do_copyout(Disk &disk, FileSystem &fs, int args, char *arg1, char *arg2);
void do_create(Disk &disk, FileSystem &fs, int args, char *arg1, char *arg2);
void do_remove(Disk &disk, FileSystem &fs, int args, char *arg1, char *arg2);
void do_stat(Disk &disk, FileSystem &fs, int args, char *arg1, char *arg2);
void do_copyin(Disk &disk, FileSystem &fs, int args, char *arg1, char *arg2);
void do_help(Disk &disk, FileSystem &fs, int args, char *arg1, char *arg2);
void do_cat(Disk &disk, FileSystem &fs, int args, char *arg1);
bool copyout(FileSystem &fs, size_t inumber, const char *path);


int main(int argc, char *argv[]) {
    Disk	disk;
	//disk.open("data/fis.txt",10);
    FileSystem	fs;
	// if(!fs.format(&disk))
	// {
	// 	printf("ERR format\n");
	// }
	// disk.open("data/fis.txt",10);
	// disk.write(2,"ana anan anana anana ana");
	// char* p=(char*)malloc(4096*sizeof(char));
	// disk.read(2,p);
	// printf("%s\n",p);
    if (argc != 3) {
    	fprintf(stderr, "Usage: %s <diskfile> <nblocks>\n", argv[0]);
    	return EXIT_FAILURE;
    }

    try {
    	disk.open(argv[1], atoi(argv[2]));
    } catch (std::runtime_error &e) {
    	fprintf(stderr, "Unable to open disk %s: %s\n", argv[1], e.what());
    	return EXIT_FAILURE;
    }

    while (true) {
	char line[BUFSIZ], cmd[BUFSIZ], arg1[BUFSIZ], arg2[BUFSIZ];

    	fprintf(stderr, "GsK FileSystem> ");
    	fflush(stderr);

    	if (fgets(line, BUFSIZ, stdin) == NULL) {
    	    break;
    	}

    	int args = sscanf(line, "%s %s %s", cmd, arg1, arg2);
    	if (args == 0) {
    	    continue;
	}

	if (streq(cmd, "debug")) {
	    do_debug(disk, fs, args, arg1, arg2);
	} else if (streq(cmd, "format")) {
	    do_format(disk, fs, args, arg1, arg2);
	} else if (streq(cmd, "mount")) {
	    do_mount(disk, fs, args, arg1, arg2);
	} else if (streq(cmd, "write")) {
	    do_copyout(disk, fs, args, arg1, arg2);
	} else if (streq(cmd, "create")) {
	    do_create(disk, fs, args, arg1, arg2);
	} else if (streq(cmd, "remove")) {
	    do_remove(disk, fs, args, arg1, arg2);
	} else if (streq(cmd, "stat")) {
	    do_stat(disk, fs, args, arg1, arg2);
	} else if (streq(cmd, "unmount")) {
	    do_unmount(disk, fs, args, arg1, arg2);
	} else if (streq(cmd, "help")) {
	    do_help(disk, fs, args, arg1, arg2);
	} else if(streq(cmd,"cat")){
		do_cat(disk,fs,args,arg1);
	} else if (streq(cmd, "exit") || streq(cmd, "quit")) {
	    break;
	} else {
	    printf("Urmatoarea comanda nu este recunoscuta: %s", line);
	    printf("Foloseste 'help' pentru a vedea toate comenzile disponibile.\n");
	}
    }
	disk.unmount();
    return EXIT_SUCCESS;
	//return 0;
}


void do_debug(Disk &disk, FileSystem &fs, int args, char *arg1, char *arg2) {
    if (args != 1) {
    	printf("Sintaxa: debug\n");
    	return;
    }

    fs.debug(&disk);
}

void do_format(Disk &disk, FileSystem &fs, int args, char *arg1, char *arg2) {
    if (args != 1) {
    	printf("Sintaxa: format\n");
    	return;
    }

    if (fs.format(&disk)) {
    	printf("Disk-ul a fost formatat cu succes.\n");
    } else {
    	printf("Formatarea disk-ului a esuat.\n");
    }
}

void do_mount(Disk &disk, FileSystem &fs, int args, char *arg1, char *arg2) {
    if (args != 1) {
    	printf("Sintaxa: mount\n");
    	return;
    }

    if (fs.mount(&disk)) {
    	printf("Disk-ul a fost montat cu succes.\n");
    } else {
    	printf("Montarea disk-ului a esuat.\n");
    }
}

void do_unmount(Disk &disk, FileSystem &fs, int args, char *arg1, char *arg2) {
    if (args != 1) {
    	printf("Sintaxa: unmount\n");
    	return;
    }

    if (fs.unmount(&disk)) {
    	printf("Disk-ul a fost demontat cu succes.\n");
    } else {
    	printf("Demontarea disk-ului a esuat.\n");
    }
}


void do_copyout(Disk &disk, FileSystem &fs, int args, char *arg1, char *arg2) {
    if (args != 3) {
        printf("Sintaxa: copyout <inode> <text>\n");
        return;
    }

    size_t inumber = atoi(arg1); // Convertim primul argument în numărul inode-ului
    char *data = arg2; // Al doilea argument este textul care trebuie scris

    ssize_t result = fs.write(&disk, inumber, data, strlen(data), 0);
    if (result < 0) {
        printf("Scrierea a esuat.\n");
    } else {
        printf("S-a scris '%s' în inode-ul %zu.\n", data, inumber);
    }
}
//HERE IN THE COPYOUT I CHANGED, TO SEE IF IT WORKS, BUT YOU DON T HAVE TO USE THAT DATA STRING

void do_create(Disk &disk, FileSystem &fs, int args, char *arg1, char *arg2) {
    if (args != 1) {
    	printf("Sintaxa: create\n");
    	return;
    }

    ssize_t inumber = fs.create(&disk);
    if (inumber >= 0) {
    	printf("A fost creat inode-ul %ld.\n", inumber);
    } else {
    	printf("Nu a fost creat niciun inode.\n");
    }
}

void do_remove(Disk &disk, FileSystem &fs, int args, char *arg1, char *arg2) {
    if (args != 2) {
    	printf("Sintaxa: remove <inode>\n");
    	return;
    }

    ssize_t inumber = atoi(arg1);
    if (fs.remove(&disk, static_cast<size_t>(inumber))) {
    	printf("A fost sters inode-ul %ld.\n", inumber);
    } else {
    	printf("Stergerea inode-ului nu a reusit.\n");
    }
}

void do_stat(Disk &disk, FileSystem &fs, int args, char *arg1, char *arg2) {
    if (args != 2) {
    	printf("Sintaxa: stat <inode>\n");
    	return;
    }

    ssize_t inumber = atoi(arg1);
    ssize_t bytes   = fs.stat(&disk,static_cast<size_t>(inumber));
    if (bytes < 0) {
    	printf("Nu se pot afisa detalii despre inode.\n");
    }
}

void do_help(Disk &disk, FileSystem &fs, int args, char *arg1, char *arg2) {
    printf("Comenzi disponibile:\n");
    printf("    format\n");
    printf("    mount\n");
	printf("    unmount\n");
    printf("    debug\n");
    printf("    create\n");
    printf("    remove <inode>\n");
    printf("    stat <inode>\n");
    printf("    write <inode> <text>\n");
    printf("    cat <inode>\n");
    printf("    help\n");
    printf("    quit\n");
    printf("    exit\n");
}

bool copyout(Disk*disk,FileSystem &fs, size_t inumber, const char *path) {
    FILE *stream = fopen(path, "w");
    if (stream == nullptr) {
    	fprintf(stderr, "Unable to open %s: %s\n", path, strerror(errno));
    	return false;
    }
//now the inodes(files) are created and the direct pointers empty,size 0 obviuosly,and do not work with the indirect, only make it work to write in the direct pls
    char buffer[4*BUFSIZ] = {0};
    size_t offset = 0;
    while (true) {
    	ssize_t result = fs.read(disk,inumber, buffer, sizeof(buffer), offset);
    	if (result <= 0) {
    	    break;
	}
	fwrite(buffer, 1, result, stream);
	offset += result;
    }

    printf("%lu bytes copied\n", offset);
    fclose(stream);
    return true;
}

void do_cat(Disk &disk, FileSystem &fs, int args, char *arg1) {
    if (args != 2) {
        printf("Sintaxa: cat <inode>\n");
        return;
    }

    size_t inumber = static_cast<size_t>(atoi(arg1)); // Convertim argumentul în numărul inode-ului
    char data[Disk::BLOCK_SIZE]; // Un buffer pentru a citi datele

    ssize_t result = fs.read(&disk,inumber, data, sizeof(data), 0); // Citim datele din inode
    if (result < 0) {
        printf("EROARE: Nu s-au putut citi datele.\n");
    } else {
        data[result] = '\0'; // Asigurăm terminarea corectă a string-ului
        printf("%s\n", data);
    }
}