// fs.cpp: File System

#include "sfs/fs.h"

#include <algorithm>
#include <unistd.h>
#include <assert.h>
#include <stdio.h>
#include <string.h>
#include <sys/mman.h>
#include <algorithm>
#include <iostream>
#include <fcntl.h>

char*FileSystem::superBlockFS=nullptr;

void FileSystem::readSuperBlock(Disk *disk, SuperBlock &superblock)
{
    if(!disk->mounted())
    {
        printf("EROARE la montarea discului\n");
        return;
    }
    Block superblk;
    disk->read(0,superblk.Data);
    std::memcpy(&superblock,&superblk.Super,sizeof(SuperBlock));
}

void FileSystem::writeSuperBlock(Disk *disk, const SuperBlock &superblock)
{
    if(!disk->mounted())
    {
        printf("EROARE la montarea discului\n");
        return;
    }
    Block superblk;
    disk->read(0,superblk.Data);
    std::memcpy(&superblk.Super,&superblock,sizeof(SuperBlock));
    disk->write(0,superblk.Data);
}

void FileSystem::readInode(Disk *disk, uint32_t inumber, Inode &inode) {
    if (!disk->mounted()) {
        printf("EROARE: Disk-ul nu este montat.\n");
        return;
    }

    uint32_t blocknum = 1 + inumber / INODES_PER_BLOCK; // Calculam blocul in care se afla inode-ul
    uint32_t offset = (inumber % INODES_PER_BLOCK) * sizeof(Inode); // Calculam offset-ul in bloc

    Block inodeBlock;
    disk->read(blocknum, inodeBlock.Data);
    std::memcpy(&inode, &inodeBlock.Inodes[offset / sizeof(Inode)], sizeof(Inode));
}

void FileSystem::writeInode(Disk *disk, uint32_t inumber, const Inode &inode) {
    if (!disk->mounted()) {
        printf("EROARE: Disk-ul nu este montat.\n");
        return;
    }

    uint32_t blocknum = 1 + inumber / INODES_PER_BLOCK;
    uint32_t offset = (inumber % INODES_PER_BLOCK) * sizeof(Inode);

    Block inodeBlock;
    disk->read(blocknum, inodeBlock.Data);
    std::memcpy(&inodeBlock.Inodes[offset / sizeof(Inode)], &inode, sizeof(Inode));
    disk->write(blocknum, inodeBlock.Data);
}

void FileSystem::readBlock(Disk *disk, uint32_t blocknum, Block &block)
{
    if(!disk->mounted())
    {
        printf("EROARE la montarea discului\n");
        return;
    }
    if(block.Data == nullptr)
    {
        printf("EROARE: Alocarea memoriei pentru block.Data a eșuat sau nu a fost făcută.\n");
        return;
    }
    disk->read(blocknum, block.Data);
}

void FileSystem::writeBlock(Disk *disk, uint32_t blocknum, const Block &block)
{
    if(!disk->mounted())
    {
        printf("EROARE la montarea discului\n");
        return;
    }
    if(block.Data == nullptr)
    {
        printf("EROARE: Pointer către date este NULL.\n");
        return;
    }
    Block writableBlock = block;
    disk->write(blocknum, writableBlock.Data);
}

void FileSystem::debug(Disk* disk) {
    Block superBlock;
    disk->read(0, superBlock.Data);

    printf("SuperBlock:\n");
    printf("    %u blocks\n", superBlock.Super.Blocks);
    printf("    %u inode blocks\n", superBlock.Super.InodeBlocks);
    printf("    %u inodes\n", superBlock.Super.Inodes);

    for (uint32_t blockNum = 1; blockNum <= superBlock.Super.InodeBlocks; ++blockNum) {
        Block inodeBlock;
        disk->read(blockNum, inodeBlock.Data);

        for (uint32_t i = 0; i < INODES_PER_BLOCK; ++i) {
            Inode& inode = inodeBlock.Inodes[i];
            if (inode.Valid) {
                printf("Inode %u:\n", (blockNum - 1) * INODES_PER_BLOCK + i);
                printf("    Size: %u bytes\n", inode.Size);
                printf("    Direct Pointers: ");
                for (uint32_t j = 0; j < POINTERS_PER_INODE; ++j) {
                    printf("%u ", inode.Direct[j]);
                }
                printf("\n");
                printf("    Indirect Pointer: %u\n", inode.Indirect);
            }
        }
    }
}

bool FileSystem::format(Disk *disk) {

    ftruncate(disk->FileDescriptor,0);

    superBlockFS=(char*)malloc(4096*sizeof(char));
    Block* superBlock=reinterpret_cast<Block*>(superBlockFS);
    superBlock->Super.MagicNumber=MAGIC_NUMBER;
    superBlock->Super.Blocks=disk->size();
    superBlock->Super.InodeBlocks=superBlock->Super.Blocks/10;
    superBlock->Super.Inodes=superBlock->Super.InodeBlocks*INODES_PER_BLOCK;

    disk->write(0,superBlockFS);
    disk->allocateBlock();

    for (uint32_t inodeBlockNum = 1; inodeBlockNum <= superBlock->Super.InodeBlocks; ++inodeBlockNum) {
        Block inodeBlock;
        // Initializare fiecare inode din blocul de inode-uri ca fiind nevalid
        for (uint32_t i = 0; i < INODES_PER_BLOCK; ++i) {
            inodeBlock.Inodes[i].Valid = 0;
        }
        // Scriere bloc de inode-uri pe disc
        disk->write(inodeBlockNum, inodeBlock.Data);
    }

    // Restul codului pentru umplerea cu date goale a blocurilor
    // Pregatim un bloc de inode-uri pentru a le adauga inainte de blocurile goale
    Block inodeBlock;
    for (uint32_t i = 0; i < INODES_PER_BLOCK; ++i) {
        inodeBlock.Inodes[i].Valid = 0;
    }

    // Adaugam blocurile de inode-uri inainte de blocurile goale
    for (uint32_t inodeBlockNum = 1; inodeBlockNum <= superBlock->Super.InodeBlocks; ++inodeBlockNum) {
        disk->write(inodeBlockNum, inodeBlock.Data);
    }

    // Adaugam blocurile goale ramase
    for (uint32_t dataBlockNum = superBlock->Super.InodeBlocks + 1; dataBlockNum < superBlock->Super.Blocks; ++dataBlockNum) {
        Block emptyBlock;
        disk->write(dataBlockNum, emptyBlock.Data);
    }

    return true;

}

bool FileSystem::mount(Disk *disk) {
    if(disk->mounted())
    {
        printf("Disk-ul e deja montat\n");
        return false;
    }
    Block* superBlockAux=reinterpret_cast<Block*>(superBlockFS);
    if(superBlockAux->Super.MagicNumber!=MAGIC_NUMBER)
    {
        printf("EROARE\n");
        return false;
    }
    disk->mount();
    return true;
}

bool FileSystem::unmount(Disk *disk)
{
    if(disk->mounted())
    {
        disk->unmount();
    }
    return true;
} 

ssize_t FileSystem::create(Disk* disk) {
    if(disk->mounted())
    {
        SuperBlock superBlock;
        readSuperBlock(disk, superBlock);

        for (uint32_t blockNum = 1; blockNum <= superBlock.InodeBlocks; ++blockNum) {
            Block inodeBlock{};
            disk->read(blockNum, inodeBlock.Data);
            for (uint32_t i = 0; i < INODES_PER_BLOCK; ++i) {
                Inode& inode = inodeBlock.Inodes[i];
                if (!inode.Valid) {
                    for(uint32_t i=0;i<POINTERS_PER_INODE;i++)
                    {
                        inode.Direct[i]=0;
                    }
                    inode.Indirect=0;
                    inode.Valid = 1;  
                    inode.Size = 0;
                    writeInode(disk, (blockNum - 1) * INODES_PER_BLOCK + i, inode);
                    return (blockNum - 1) * INODES_PER_BLOCK + i;
                }
            }
        }
        printf("Nu s-au găsit inode-uri libere\n");
        return -1;
    }
    else
    {
        printf("EROARE:Disk-ul nu este montat\n");
        return -1;
    }
}

bool FileSystem::remove(Disk* disk, size_t inumber) {
    printf("A intrat in remove!\n");
    SuperBlock superBlock;
    readSuperBlock(disk, superBlock);

    uint32_t blockNum = 1 + inumber / INODES_PER_BLOCK;
    uint32_t offset = (inumber % INODES_PER_BLOCK) * sizeof(Inode);

    Inode inode;
    readInode(disk, inumber, inode);

    if (!inode.Valid) {
        printf("EROARE: Inode-ul nu este valid.\n");
        return false;
    }

    printf("Ne pregatim sa eliberam blocurile directe!\n");
    for (uint32_t i = 0; i < POINTERS_PER_INODE; ++i) {
        if (inode.Direct[i] != 0) {
            disk->freeBlock(inode.Direct[i]);
            inode.Direct[i] = 0;
        }
    }

    if (inode.Indirect != 0) {
        Block indirectBlock;
        disk->read(inode.Indirect, indirectBlock.Data);

        for (uint32_t i = 0; i < POINTERS_PER_BLOCK; ++i) {
            if (indirectBlock.Pointers[i] != 0) {
                disk->freeBlock(indirectBlock.Pointers[i]);
                indirectBlock.Pointers[i] = 0;
            }
        }
        disk->freeBlock(inode.Indirect);
        inode.Indirect = 0;
    }
    inode.Valid = 0;
    inode.Size = 0;
    writeInode(disk, inumber, inode);

    return true;
}


ssize_t FileSystem::stat(Disk* disk, size_t inumber) {
    if(disk->mounted())
    {
        Inode inode;
        readInode(disk, inumber, inode);

        if (!inode.Valid) {
            printf("EROARE: Inode-ul nu este valid.\n");
            return -1; 
        }

        printf("Inode %zu:\n", inumber);
        printf("    Size: %u bytes\n", inode.Size);
        printf("    Direct Pointers: ");
        for (uint32_t i = 0; i < POINTERS_PER_INODE; ++i) {
            printf("%u ", inode.Direct[i]);
        }
        printf("\n");
        printf("    Indirect Pointer: %u\n", inode.Indirect);

        return 0; 
    }
    else
    {
        printf("EROARE: Disk-ul nu este montat\n");
    }
}

ssize_t FileSystem::read(Disk*disk,size_t inumber, char *data, size_t length, size_t offset) {
    if(disk->mounted())
    {
        Inode inode;
        readInode(disk, inumber, inode);

        if (!inode.Valid) {
            printf("EROARE: Inode-ul nu este valid.\n");
            return -1; 
        }

        if (offset >= inode.Size) {
            // Daca offset-ul este mai mare decât marimea fisierului, nu avem ce citi
            return 0;
        }

        if (offset + length > inode.Size) {
            
            length = inode.Size - offset; //// Ajustam lungimea daca depaseste marimea fisierului
        }

        size_t bytesLeft = length;
        size_t totalRead = 0;

        // Citim blocurile de date incepand de la offset
        while (bytesLeft > 0 && totalRead < length) {
            size_t blockIndex = (offset + totalRead) / Disk::BLOCK_SIZE;
            if (blockIndex >= POINTERS_PER_INODE) {
                break;
            }

            uint32_t blockNum = inode.Direct[blockIndex];
            if (blockNum == 0) {
                break;
            }

            size_t internalOffset = (offset + totalRead) % Disk::BLOCK_SIZE;
            size_t toRead = std::min(bytesLeft, Disk::BLOCK_SIZE - internalOffset);

            Block block;
            readBlock(disk, blockNum, block);
            memcpy(data + totalRead, block.Data + internalOffset, toRead);

            totalRead += toRead;
            bytesLeft -= toRead;
        }

        return totalRead;
    }
    else
    {
        printf("EROARE: Disk-ul nu este montat\n");
        return -1;
    }
}





ssize_t FileSystem::write(Disk* disk, size_t inumber, char *data, size_t length, size_t offset) 
{
    if(disk->mounted())
    {
        // Citim inode-ul
        Inode inode;
        readInode(disk, inumber, inode);

        if (!inode.Valid) {
            printf("EROARE: Inode-ul nu este valid.\n");
            return -1; 
        }

        size_t written = 0;

        while (length > 0) {
            // Calculeaza indexul blocului si offset-ul intern in bloc
            size_t blockIndex = offset / Disk::BLOCK_SIZE;
            size_t internalOffset = offset % Disk::BLOCK_SIZE;
            size_t amountToWrite = std::min(Disk::BLOCK_SIZE - internalOffset, length);

            // Verifica daca blocul curent este alocat, daca nu, alocati unul nou
            if (inode.Direct[blockIndex] == 0) {
                inode.Direct[blockIndex] = disk->allocateBlock();
                if (inode.Direct[blockIndex] == 0) {
                    printf("EROARE: Nu s-au putut aloca blocuri noi.\n");
                    return -1;
                }
            }

            disk->writeBlock(inode.Direct[blockIndex], data + written, amountToWrite, internalOffset);

            // Actualizeaza pointerii si lungimea ramasa de scris
            data += amountToWrite;
            offset += amountToWrite;
            length -= amountToWrite;
            written += amountToWrite;

            // Verifica daca trebuie actualizata dimensiunea inode-ului
            if (offset > inode.Size) {
                inode.Size = offset;
            }
        }

        // Scrie inode-ul actualizat pe disc
        writeInode(disk, inumber, inode);

        return written; // Returneaza numarul total de octeti scrisi
    }
    else
    {
        printf("EROARE: Disk-ul nu este montat\n");
        return -1;
    }    
}




