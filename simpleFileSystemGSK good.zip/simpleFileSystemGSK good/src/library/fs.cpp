// fs.cpp: File System

#include "sfs/fs.h"

#include <algorithm>
#include <unistd.h>
#include <assert.h>
#include <stdio.h>
#include <string.h>

char*FileSystem::superBlockFS=nullptr;
// Debug file system -----------------------------------------------------------

void FileSystem::readSuperBlock(Disk *disk, SuperBlock &superblock)
{
    if(!disk->mounted())
    {
        printf("EROARE la montarea discului\n");
        return;
    }
    Block superblk;
    disk->read(0,superblk.Data);
    std::memcpy(&superblock,&superblk.Super,sizeof(SuperBlock));
}

void FileSystem::writeSuperBlock(Disk *disk, const SuperBlock &superblock)
{
    if(!disk->mounted())
    {
        printf("EROARE la montarea discului\n");
        return;
    }
    Block superblk;
    disk->read(0,superblk.Data);
    std::memcpy(&superblk.Super,&superblock,sizeof(SuperBlock));
    disk->write(0,superblk.Data);
}

void FileSystem::readInode(Disk *disk, uint32_t inumber, Inode &inode)
{
    if(!disk->mounted())
    {
        printf("EROARE la montarea discului\n");
        return;
    }
    uint32_t blocknum=1+inumber/INODES_PER_BLOCK;
    uint32_t offset=(inumber%INODES_PER_BLOCK)*sizeof(Inode);

    Block inodeBlock;
    disk->read(blocknum,inodeBlock.Data);
    std::memcpy(&inode,reinterpret_cast<char*>(&inodeBlock.Inodes)+offset,sizeof(Inode));
}

void FileSystem::writeInode(Disk *disk, uint32_t inumber, const Inode &inode)
{
    if(!disk->mounted())
    {
        printf("EROARE la montarea discului\n");
        return;
    }
    uint32_t blocknum = 1 + inumber / INODES_PER_BLOCK;
    uint32_t offset = (inumber % INODES_PER_BLOCK) * sizeof(Inode);

    Block inodeBlock;
    disk->read(blocknum, inodeBlock.Data);

    std::memcpy(reinterpret_cast<char*>(inodeBlock.Inodes) + offset, &inode, sizeof(Inode));

    disk->write(blocknum, inodeBlock.Data);
}

void FileSystem::readBlock(Disk *disk, uint32_t blocknum, Block &block)
{
    if(!disk->mounted())
    {
        printf("EROARE la montarea discului\n");
        return;
    }
    disk->read(blocknum,block.Data);
}

void FileSystem::writeBlock(Disk *disk, uint32_t blocknum, const Block &block)
{
    if(!disk->mounted())
    {
        printf("EROARE la montarea discului\n");
        return;
    }
    Block writableBlock = block;
    disk->write(blocknum, writableBlock.Data);
}

void FileSystem::debug(Disk* disk) {
    Block superBlock;
    // Citim superblock-ul
    disk->read(0, superBlock.Data);

    printf("SuperBlock:\n");
    printf("    %u blocks\n", superBlock.Super.Blocks);
    printf("    %u inode blocks\n", superBlock.Super.InodeBlocks);
    printf("    %u inodes\n", superBlock.Super.Inodes);

    // Afișăm informații despre inode-uri
    for (uint32_t blockNum = 1; blockNum <= superBlock.Super.InodeBlocks; ++blockNum) {
        Block inodeBlock;
        disk->read(blockNum, inodeBlock.Data);

        for (uint32_t i = 0; i < INODES_PER_BLOCK; ++i) {
            Inode& inode = inodeBlock.Inodes[i];
            if (inode.Valid) {
                printf("Inode %u:\n", (blockNum - 1) * INODES_PER_BLOCK + i);
                printf("    Size: %u bytes\n", inode.Size);
                printf("    Direct Pointers: ");
                for (uint32_t j = 0; j < POINTERS_PER_INODE; ++j) {
                    printf("%u ", inode.Direct[j]);
                }
                printf("\n");
                printf("    Indirect Pointer: %u\n", inode.Indirect);
            }
        }
    }
}


// Format file system ----------------------------------------------------------

bool FileSystem::format(Disk *disk) {

    ftruncate(disk->FileDescriptor,0);

    superBlockFS=(char*)malloc(4096*sizeof(char));
    Block* superBlock=reinterpret_cast<Block*>(superBlockFS);
    superBlock->Super.MagicNumber=MAGIC_NUMBER;
    superBlock->Super.Blocks=disk->size();
    superBlock->Super.InodeBlocks=superBlock->Super.Blocks/10;
    superBlock->Super.Inodes=superBlock->Super.InodeBlocks*INODES_PER_BLOCK;

    disk->write(0,superBlockFS);

    for (uint32_t inodeBlockNum = 1; inodeBlockNum <= superBlock->Super.InodeBlocks; ++inodeBlockNum) {
        Block inodeBlock;
        // Inițializare fiecare inode din blocul de inode-uri ca fiind nevalid
        for (uint32_t i = 0; i < INODES_PER_BLOCK; ++i) {
            inodeBlock.Inodes[i].Valid = 0;
        }
        // Scriere bloc de inode-uri pe disc
        disk->write(inodeBlockNum, inodeBlock.Data);
    }

    // Restul codului pentru umplerea cu date goale a blocurilor
    // Pregătim un bloc de inode-uri pentru a le adăuga înainte de blocurile goale
    Block inodeBlock;
    for (uint32_t i = 0; i < INODES_PER_BLOCK; ++i) {
        inodeBlock.Inodes[i].Valid = 0;
    }

    // Adăugăm blocurile de inode-uri înainte de blocurile goale
    for (uint32_t inodeBlockNum = 1; inodeBlockNum <= superBlock->Super.InodeBlocks; ++inodeBlockNum) {
        disk->write(inodeBlockNum, inodeBlock.Data);
    }

    // Adăugăm blocurile goale rămase
    for (uint32_t dataBlockNum = superBlock->Super.InodeBlocks + 1; dataBlockNum < superBlock->Super.Blocks; ++dataBlockNum) {
        Block emptyBlock;
        disk->write(dataBlockNum, emptyBlock.Data);
    }

    return true;

}

// Mount file system -----------------------------------------------------------

bool FileSystem::mount(Disk *disk) {
    if(disk->mounted())
    {
        printf("Disk-ul e deja montat\n");
        return false;
    }
    Block* superBlockAux=reinterpret_cast<Block*>(superBlockFS);
    if(superBlockAux->Super.MagicNumber!=MAGIC_NUMBER)
    {
        printf("EROARE\n");
        return false;
    }
    disk->mount();
    return true;
}

// Create inode ----------------------------------------------------------------

ssize_t FileSystem::create(Disk* disk) {
    SuperBlock superBlock;
    readSuperBlock(disk, superBlock);

    for (uint32_t blockNum = 1; blockNum <= superBlock.InodeBlocks; ++blockNum) {
        Block inodeBlock{};
        disk->read(blockNum, inodeBlock.Data);
        for (uint32_t i = 0; i < INODES_PER_BLOCK; ++i) {
            Inode& inode = inodeBlock.Inodes[i];
            if (!inode.Valid) {
                for(int i=0;i<POINTERS_PER_INODE;i++)
                {
                    inode.Direct[i]=0;
                }
                inode.Indirect=0;
                inode.Valid = 1;  // este valid
                inode.Size = 0;
                writeInode(disk, (blockNum - 1) * INODES_PER_BLOCK + i, inode);
                // returnează numărul inode-ului creat
                return (blockNum - 1) * INODES_PER_BLOCK + i;
            }
        }
    }
    printf("Nu s-au găsit inode-uri libere\n");
    return -1;
}


// Remove inode ----------------------------------------------------------------

bool FileSystem::remove(Disk* disk, size_t inumber) {
    // Citirea informațiilor din SuperBlock
    SuperBlock superBlock;
    readSuperBlock(disk, superBlock);

    // Determinarea blocului și offset-ului corespunzător inode-ului
    uint32_t blockNum = 1 + inumber / INODES_PER_BLOCK;
    uint32_t offset = (inumber % INODES_PER_BLOCK) * sizeof(Inode);

    // Citirea inode-ului
    Inode inode;
    readInode(disk, inumber, inode);

    // Verificăm dacă inode-ul este valid
    if (!inode.Valid) {
        printf("EROARE: Inode-ul nu este valid.\n");
        return false;
    }

    // Eliberarea blocurilor directe
    for (uint32_t i = 0; i < POINTERS_PER_INODE; ++i) {
        if (inode.Direct[i] != 0) {
            // Eliberăm blocul direct
            disk->freeBlock(inode.Direct[i]);
            // Setăm pointer-ul direct la 0 pentru a indica că blocul a fost eliberat
            inode.Direct[i] = 0;
        }
    }

    // Eliberarea blocurilor indirecte
    if (inode.Indirect != 0) {
        // Citim blocul indirect
        Block indirectBlock;
        disk->read(inode.Indirect, indirectBlock.Data);

        // Eliberăm toate blocurile indicate de blocul indirect
        for (uint32_t i = 0; i < POINTERS_PER_BLOCK; ++i) {
            if (indirectBlock.Pointers[i] != 0) {
                disk->freeBlock(indirectBlock.Pointers[i]);
                // Setăm pointer-ul indirect la 0 pentru a indica că blocul a fost eliberat
                indirectBlock.Pointers[i] = 0;
            }
        }

        // Eliberăm blocul indirect
        disk->freeBlock(inode.Indirect);
        // Setăm pointer-ul indirect al inode-ului la 0 pentru a indica că blocul a fost eliberat
        inode.Indirect = 0;
    }

    // Marcăm inode-ul ca nevalid și îl scriem înapoi pe disc
    inode.Valid = 0;
    writeInode(disk, inumber, inode);

    return true;
}


// Inode stat ------------------------------------------------------------------

ssize_t FileSystem::stat(Disk* disk, size_t inumber) {
    // Load inode information
    Inode inode;
    readInode(disk, inumber, inode);

    // Verificăm dacă inode-ul este valid
    if (!inode.Valid) {
        printf("EROARE: Inode-ul nu este valid.\n");
        return -1; // Întoarce un cod de eroare sau -1 pentru a indica o problemă
    }

    // Afișarea informațiilor despre inode
    printf("Inode %zu:\n", inumber);
    printf("    Size: %u bytes\n", inode.Size);
    printf("    Direct Pointers: ");
    for (uint32_t i = 0; i < POINTERS_PER_INODE; ++i) {
        printf("%u ", inode.Direct[i]);
    }
    printf("\n");
    printf("    Indirect Pointer: %u\n", inode.Indirect);

    return 0; // Întoarce 0 pentru a indica succesul
}

// Read from inode -------------------------------------------------------------

ssize_t FileSystem::read(size_t inumber, char *data, size_t length, size_t offset) {
    // Load inode information

    // Adjust length

    // Read block and copy to data
    return 0;
}

// Write to inode --------------------------------------------------------------

ssize_t FileSystem::write(size_t inumber, char *data, size_t length, size_t offset) {
    // Load inode
    
    // Write block and copy to data
    return 0;
}
